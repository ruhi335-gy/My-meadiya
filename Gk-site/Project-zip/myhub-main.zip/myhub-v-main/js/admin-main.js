
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, collection, getDocs, addDoc, updateDoc, deleteDoc, doc, getDoc, setDoc, query, orderBy }
  from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged }
  from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

// ===== 🔥 APNA FIREBASE CONFIG YAHAN DALO (same as index.html) =====
const firebaseConfig = {
  apiKey: "AIzaSyCwhf1lOtZXj13wyrNI0mfUSeQj8Cs3iJM",
  authDomain: "gkchat-959fb.firebaseapp.com",
  databaseURL: "https://gkchat-959fb-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "gkchat-959fb",
  storageBucket: "gkchat-959fb.firebasestorage.app",
  messagingSenderId: "654177877506",
  appId: "1:654177877506:web:9b1f302686c9f408e3311b"
};
// ====================================================================

const app  = initializeApp(firebaseConfig);
const db   = getFirestore(app);
const auth = getAuth(app);

// ---- In-memory caches (used by Edit buttons & export) ----
let _apps = [], _tools = [], _projects = [], _websites = [], _subscribers = [], _messages = [], _settings = {};
let editAppId = null, editToolId = null, editProjId = null, editWebId = null;

// ---- Auth Check ----
onAuthStateChanged(auth, user => {
  if(user) {
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('adminPanel').style.display  = 'block';
    loadAll();
  } else {
    document.getElementById('loginScreen').style.display = 'flex';
    document.getElementById('adminPanel').style.display  = 'none';
  }
});

window.handleLogin = async (e) => {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value;
  const pass  = document.getElementById('loginPass').value;
  try {
    await signInWithEmailAndPassword(auth, email, pass);
    document.getElementById('loginError').style.display = 'none';
  } catch(err) {
    document.getElementById('loginError').style.display = 'block';
  }
};

window.handleLogout = () => signOut(auth);

// ---- Load All ----
async function loadAll() {
  const [aSnap,tSnap,pSnap,wSnap,subSnap,msgSnap,setSnap] = await Promise.all([
    getDocs(query(collection(db,'apps'),        orderBy('createdAt','desc'))),
    getDocs(query(collection(db,'tools'),       orderBy('createdAt','desc'))),
    getDocs(query(collection(db,'projects'),    orderBy('createdAt','desc'))),
    getDocs(query(collection(db,'websites'),    orderBy('createdAt','desc'))),
    getDocs(query(collection(db,'subscribers'), orderBy('date','desc'))),
    getDocs(query(collection(db,'messages'),    orderBy('date','desc'))),
    getDoc(doc(db,'settings','unlock'))
  ]);
  _apps        = aSnap.docs.map(d=>({id:d.id,...d.data()}));
  _tools       = tSnap.docs.map(d=>({id:d.id,...d.data()}));
  _projects    = pSnap.docs.map(d=>({id:d.id,...d.data()}));
  _websites    = wSnap.docs.map(d=>({id:d.id,...d.data()}));
  _subscribers = subSnap.docs.map(d=>({id:d.id,...d.data()}));
  _messages    = msgSnap.docs.map(d=>({id:d.id,...d.data()}));
  _settings    = setSnap.exists() ? setSnap.data() : {};

  await Promise.all([
    ensureCodes(_apps,'apps'),
    ensureCodes(_tools,'tools'),
    ensureCodes(_projects,'projects')
  ]);

  renderGrid('appsGrid',     _apps,     'app');
  renderGrid('toolsGrid',    _tools,    'tool');
  renderGrid('projectsGrid', _projects, 'project');
  renderGrid('websitesGrid', _websites, 'website');
  renderSubscribers();
  renderMessages();
  fillSettingsForm();
}

function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function escAttr(s){ return String(s||'').replace(/"/g,'&quot;'); }
function fmtDate(d){ try{ return new Date(d).toLocaleString(); }catch(e){ return d||''; } }

/* ---- Random confirmation code (avoids ambiguous chars like 0/O/1/I) ---- */
function genCode(len=6){
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let c = '';
  for(let i=0;i<len;i++) c += chars[Math.floor(Math.random()*chars.length)];
  return c;
}

/* ---- Backfill a code onto any existing item that doesn't have one yet ---- */
async function ensureCodes(items, colName){
  for(const it of items){
    if(!it.code){
      const code = genCode();
      it.code = code;
      try { await updateDoc(doc(db,colName,it.id), {code}); } catch(e){ console.error(e); }
    }
  }
}

window.copyCode = (code, btn) => {
  const fb = () => { const ta=document.createElement('textarea'); ta.value=code; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta); };
  (navigator.clipboard ? navigator.clipboard.writeText(code).catch(fb) : Promise.resolve(fb()))
    .then(() => { const o=btn.textContent; btn.textContent='Copied!'; setTimeout(()=>btn.textContent=o, 1200); });
};

function renderGrid(containerId, items, type) {
  const g = document.getElementById(containerId);
  if(!items||items.length===0){ g.innerHTML='<p class="empty-msg">No items yet.</p>'; return; }
  const editFn = type==='app' ? 'editApp' : type==='tool' ? 'editTool' : type==='website' ? 'editWebsite' : 'editProject';
  g.innerHTML = items.map(item => {
    const img = item.img || 'https://placehold.co/300x200?text=No+Image';
    return `<div class="card">
      <img src="${img}" alt="${esc(item.name)}" onerror="this.src='https://placehold.co/300x200?text=No+Image'">
      <h3>${esc(item.name)}</h3>
      <p class="tool-link">Code: <strong>${esc(item.code||'—')}</strong>${item.code ? ` <button class="btn-edit" style="padding:3px 10px;font-size:11px" onclick="copyCode('${escAttr(item.code)}',this)">Copy</button>` : ''}</p>
      <div class="card-actions">
        <button class="btn-edit" onclick="${editFn}('${item.id}')">Edit</button>
        <button class="btn-delete" onclick="deleteItem('${type}s','${item.id}')">Delete</button>
      </div>
    </div>`;
  }).join('');
}

function renderSubscribers(){
  const g = document.getElementById('subscribersGrid');
  if(!g) return;
  if(!_subscribers.length){ g.innerHTML = '<p class="empty-msg">No subscribers yet.</p>'; return; }
  g.innerHTML = _subscribers.map(s => `<div class="info-card">
    <div class="ic-top">
      <span class="ic-name">${esc(s.name)}</span>
      <span class="ic-email">${esc(s.email)}</span>
    </div>
    <div class="ic-date">Subscribed: ${fmtDate(s.date)}</div>
    <div class="card-actions" style="padding-top:10px">
      <button class="btn-delete" onclick="deleteItem('subscribers','${s.id}')">Delete</button>
    </div>
  </div>`).join('');
}

function renderMessages(){
  const g = document.getElementById('messagesGrid');
  if(!g) return;
  if(!_messages.length){ g.innerHTML = '<p class="empty-msg">No messages yet.</p>'; return; }
  g.innerHTML = _messages.map(m => `<div class="info-card">
    <div class="ic-top">
      <span class="ic-name">${esc(m.name)}</span>
      <a class="ic-email" href="mailto:${escAttr(m.email)}">${esc(m.email)}</a>
    </div>
    <p class="ic-msg">${esc(m.message)}</p>
    <div class="ic-date">${fmtDate(m.date)}</div>
    <div class="card-actions" style="padding-top:10px">
      <button class="btn-delete" onclick="deleteItem('messages','${m.id}')">Delete</button>
    </div>
  </div>`).join('');
}

// ---- Export subscribers as subscribe.txt ----
window.exportSubscribers = () => {
  if(!_subscribers.length){ alert('No subscribers to export yet.'); return; }
  const lines = _subscribers.map(s => `${s.name} <${s.email}>`).join('\n');
  const blob = new Blob([lines], {type:'text/plain'});
  const url  = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'subscribe.txt';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

// ---- Settings (Subscribe-to-Unlock links) ----
function fillSettingsForm(){
  document.getElementById('setYoutube').value   = _settings.youtube   || '';
  document.getElementById('setTelegram').value  = _settings.telegram  || '';
  document.getElementById('setInstagram').value = _settings.instagram|| '';
  document.getElementById('setWhatsapp').value  = _settings.whatsapp || '';
}

window.saveSettings = async () => {
  const youtube   = document.getElementById('setYoutube').value.trim();
  const telegram  = document.getElementById('setTelegram').value.trim();
  const instagram = document.getElementById('setInstagram').value.trim();
  const whatsapp  = document.getElementById('setWhatsapp').value.trim();
  await setDoc(doc(db,'settings','unlock'), {youtube,telegram,instagram,whatsapp});
  _settings = {youtube,telegram,instagram,whatsapp};
  showToast('Unlock links saved!');
};

// ---- Reset modal back to "Add" mode (called whenever a modal is closed) ----
window.resetModalState = (id) => {
  if(id === 'addAppModal'){
    editAppId = null;
    document.getElementById('appModalTitle').textContent = 'Add New App';
    document.getElementById('appSubmitBtn').textContent  = 'Add App';
    clearFields(['appName','appImg','appDesc','appVideo','appDownload']);
  } else if(id === 'addToolModal'){
    editToolId = null;
    document.getElementById('toolModalTitle').textContent = 'Add New Tool';
    document.getElementById('toolSubmitBtn').textContent  = 'Add Tool';
    clearFields(['toolName','toolImg','toolDesc','toolGithub','toolVideo']);
    document.getElementById('commandsContainer').innerHTML =
      '<div class="command-input-row"><input type="text" class="tool-cmd" placeholder="Command"></div>';
  } else if(id === 'addProjectModal'){
    editProjId = null;
    document.getElementById('projectModalTitle').textContent = 'Add New Project';
    document.getElementById('projectSubmitBtn').textContent  = 'Add Project';
    clearFields(['projName','projImg','projDesc','projLive','projSource','projDownload']);
  } else if(id === 'addWebsiteModal'){
    editWebId = null;
    document.getElementById('websiteModalTitle').textContent = 'Add New Website';
    document.getElementById('websiteSubmitBtn').textContent  = 'Add Website';
    clearFields(['webName','webImg','webDesc','webLink','webVideo']);
  }
};

// ---- Edit App ----
window.editApp = (id) => {
  const a = _apps.find(x=>x.id===id);
  if(!a) return;
  document.getElementById('appName').value     = a.name||'';
  document.getElementById('appImg').value      = a.img||'';
  document.getElementById('appDesc').value     = a.description||'';
  document.getElementById('appVideo').value    = a.videoUrl||'';
  document.getElementById('appDownload').value = a.downloadLink||'';
  editAppId = id;
  document.getElementById('appModalTitle').textContent = 'Edit App';
  document.getElementById('appSubmitBtn').textContent  = 'Update App';
  openModal('addAppModal');
};

// ---- Edit Tool ----
window.editTool = (id) => {
  const t = _tools.find(x=>x.id===id);
  if(!t) return;
  document.getElementById('toolName').value   = t.name||'';
  document.getElementById('toolImg').value    = t.img||'';
  document.getElementById('toolDesc').value   = t.description||'';
  document.getElementById('toolGithub').value = t.githubLink||'';
  document.getElementById('toolVideo').value  = t.videoUrl||'';
  const cmds = (t.commands && t.commands.length) ? t.commands : [''];
  document.getElementById('commandsContainer').innerHTML = cmds.map(c =>
    `<div class="command-input-row"><input type="text" class="tool-cmd" value="${escAttr(c)}" placeholder="Command"><button type="button" class="btn-remove" onclick="this.parentElement.remove()">×</button></div>`
  ).join('');
  editToolId = id;
  document.getElementById('toolModalTitle').textContent = 'Edit Tool';
  document.getElementById('toolSubmitBtn').textContent  = 'Update Tool';
  openModal('addToolModal');
};

// ---- Edit Project ----
window.editProject = (id) => {
  const p = _projects.find(x=>x.id===id);
  if(!p) return;
  document.getElementById('projName').value     = p.name||'';
  document.getElementById('projImg').value      = p.img||'';
  document.getElementById('projDesc').value     = p.description||'';
  document.getElementById('projLive').value     = p.liveLink||'';
  document.getElementById('projSource').value   = p.sourceLink||'';
  document.getElementById('projDownload').value = p.downloadLink||'';
  editProjId = id;
  document.getElementById('projectModalTitle').textContent = 'Edit Project';
  document.getElementById('projectSubmitBtn').textContent  = 'Update Project';
  openModal('addProjectModal');
};

// ---- Add / Update App ----
window.addApp = async () => {
  const name  = document.getElementById('appName').value.trim();
  const img   = document.getElementById('appImg').value.trim();
  const desc  = document.getElementById('appDesc').value.trim();
  const video = document.getElementById('appVideo').value.trim();
  const dl    = document.getElementById('appDownload').value.trim();
  if(!name||!dl){ alert('Name and download link required'); return; }
  if(editAppId){
    await updateDoc(doc(db,'apps',editAppId), {name,img,description:desc,videoUrl:video,downloadLink:dl});
    showToast('App updated!');
  } else {
    await addDoc(collection(db,'apps'), {name,img,description:desc,videoUrl:video,downloadLink:dl,code:genCode(),createdAt:new Date().toISOString()});
    showToast('App added!');
  }
  closeModal('addAppModal');
  loadAll();
};

// ---- Add / Update Tool ----
window.addTool = async () => {
  const name   = document.getElementById('toolName').value.trim();
  const img    = document.getElementById('toolImg').value.trim();
  const desc   = document.getElementById('toolDesc').value.trim();
  const video  = document.getElementById('toolVideo').value.trim();
  const github = document.getElementById('toolGithub').value.trim();
  if(!name){ alert('Tool name required'); return; }
  const cmds = [...document.querySelectorAll('.tool-cmd')]
    .map(i=>i.value.trim()).filter(Boolean);
  if(editToolId){
    await updateDoc(doc(db,'tools',editToolId), {name,img,description:desc,videoUrl:video,githubLink:github,commands:cmds});
    showToast('Tool updated!');
  } else {
    await addDoc(collection(db,'tools'), {name,img,description:desc,videoUrl:video,githubLink:github,commands:cmds,code:genCode(),createdAt:new Date().toISOString()});
    showToast('Tool added!');
  }
  closeModal('addToolModal');
  loadAll();
};

// ---- Add / Update Project ----
window.addProject = async () => {
  const name   = document.getElementById('projName').value.trim();
  const img    = document.getElementById('projImg').value.trim();
  const desc   = document.getElementById('projDesc').value.trim();
  const live   = document.getElementById('projLive').value.trim();
  const source = document.getElementById('projSource').value.trim();
  const dl     = document.getElementById('projDownload').value.trim();
  if(!name||!dl){ alert('Name and download link required'); return; }
  if(editProjId){
    await updateDoc(doc(db,'projects',editProjId), {name,img,description:desc,liveLink:live,sourceLink:source,downloadLink:dl});
    showToast('Project updated!');
  } else {
    await addDoc(collection(db,'projects'), {name,img,description:desc,liveLink:live,sourceLink:source,downloadLink:dl,code:genCode(),createdAt:new Date().toISOString()});
    showToast('Project added!');
  }
  closeModal('addProjectModal');
  loadAll();
};

// ---- Edit Website ----
window.editWebsite = (id) => {
  const w = _websites.find(x=>x.id===id);
  if(!w) return;
  document.getElementById('webName').value  = w.name||'';
  document.getElementById('webImg').value   = w.img||'';
  document.getElementById('webDesc').value  = w.description||'';
  document.getElementById('webLink').value  = w.websiteLink||'';
  document.getElementById('webVideo').value = w.videoUrl||'';
  editWebId = id;
  document.getElementById('websiteModalTitle').textContent = 'Edit Website';
  document.getElementById('websiteSubmitBtn').textContent  = 'Update Website';
  openModal('addWebsiteModal');
};

// ---- Add / Update Website ----
window.addWebsite = async () => {
  const name  = document.getElementById('webName').value.trim();
  const img   = document.getElementById('webImg').value.trim();
  const desc  = document.getElementById('webDesc').value.trim();
  const link  = document.getElementById('webLink').value.trim();
  const video = document.getElementById('webVideo').value.trim();
  if(!name){ alert('Website name required'); return; }
  if(editWebId){
    await updateDoc(doc(db,'websites',editWebId), {name,img,description:desc,websiteLink:link,videoUrl:video});
    showToast('Website updated!');
  } else {
    await addDoc(collection(db,'websites'), {name,img,description:desc,websiteLink:link,videoUrl:video,createdAt:new Date().toISOString()});
    showToast('Website added!');
  }
  closeModal('addWebsiteModal');
  loadAll();
};

// ---- Delete (works for apps/tools/projects/websites/subscribers/messages) ----
window.deleteItem = async (colName, id) => {
  if(!confirm('Delete this item?')) return;
  await deleteDoc(doc(db, colName, id));
  showToast('Deleted!');
  loadAll();
};

function clearFields(ids){ ids.forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; }); }
