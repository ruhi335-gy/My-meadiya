
// ---- Tab Switching ----
window.switchTab = (tab) => {
  document.querySelectorAll('.tab-section').forEach(s=>s.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('tab-active'));
  document.getElementById('tab-'+tab).classList.add('active');
  event.target.classList.add('tab-active');
};

// ---- Modals ----
window.openModal  = id => document.getElementById(id).classList.add('active');
window.closeModal = id => {
  document.getElementById(id).classList.remove('active');
  if(window.resetModalState) window.resetModalState(id);
};
document.querySelectorAll('.modal-overlay').forEach(o=>{
  o.addEventListener('click',e=>{ if(e.target===o) window.closeModal(o.id); });
});

// ---- Add Command Field ----
window.addCommandField = () => {
  const row = document.createElement('div');
  row.className = 'command-input-row';
  row.innerHTML = '<input type="text" class="tool-cmd" placeholder="Command"><button type="button" class="btn-remove" onclick="this.parentElement.remove()">×</button>';
  document.getElementById('commandsContainer').appendChild(row);
};

// ---- Toast ----
window.showToast = (msg) => {
  const t = document.getElementById('toast');
  t.textContent = '✅ '+msg;
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),2500);
};
