document.getElementById('yr').textContent = new Date().getFullYear();

/* All view IDs */
const ALL_VIEWS = ['home','tools','tool-detail','apps','app-detail','projects','project-detail','websites','website-detail','search','about','contact','privacy','terms','disclaimer'];

/* ─ go(viewName, type, id)
   type & id are for detail pages, used to build the share URL and history state ─ */
window.go = (viewName, type, id) => {
  ALL_VIEWS.forEach(v => {
    const el = document.getElementById('v-'+v);
    if(el) el.classList.remove('on');
  });
  const target = document.getElementById('v-'+viewName);
  if(target) target.classList.add('on');
  window.scrollTo({top:0, behavior:'smooth'});

  /* Build URL param */
  let urlParam = '?';
  if(type && id){
    const key = type==='proj' ? 'project' : type;
    urlParam = `?${key}=${id}`;
  } else if(viewName !== 'home'){
    urlParam = `?p=${viewName}`;
  }

  const state = { view: viewName, type: type||null, id: id||null };
  history.pushState(state, '', urlParam);
};

/* ─ Browser back/forward button ─ */
window.addEventListener('popstate', ev => {
  if(!ev.state){ showView('home'); return; }
  const {view, type, id} = ev.state;

  /* If it's a detail page with an id, re-render the detail */
  if(id && type){
    if(type==='tool')    { window.openToolDetail    && openToolDetail(id);    return; }
    if(type==='app')     { window.openAppDetail     && openAppDetail(id);     return; }
    if(type==='proj')    { window.openProjDetail    && openProjDetail(id);    return; }
    if(type==='website') { window.openWebsiteDetail && openWebsiteDetail(id); return; }
  }
  showView(view || 'home');
});

function showView(name){
  ALL_VIEWS.forEach(v=>{ const el=document.getElementById('v-'+v); if(el) el.classList.remove('on'); });
  const el = document.getElementById('v-'+(name||'home'));
  if(el) el.classList.add('on');
  window.scrollTo({top:0, behavior:'smooth'});
}

/* Initial state — preserve the URL the user actually opened (deep link),
   don't reset it to '?' or Firebase routing will never find the id */
history.replaceState({view:'home', type:null, id:null}, '', location.search || '?');

/* ─ HAMBURGER ─ */
const hbBtn  = document.getElementById('hbBtn');
const smenu  = document.getElementById('smenu');
const smClose= document.getElementById('smClose');
const ovEl   = document.getElementById('ov');
window.CM = () => { smenu.classList.remove('open'); ovEl.classList.remove('on'); document.body.style.overflow=''; };
hbBtn.addEventListener('click', () => { smenu.classList.add('open'); ovEl.classList.add('on'); document.body.style.overflow='hidden'; });
smClose.addEventListener('click', CM);
ovEl.addEventListener('click', CM);

/* ─ MODALS ─ */
window.OM  = id => { document.getElementById(id).classList.add('on');  document.body.style.overflow='hidden'; };
window.CM2 = id => { const el=document.getElementById(id); if(el) el.classList.remove('on'); if(!document.querySelector('.mov.on')) document.body.style.overflow=''; };
document.querySelectorAll('.mov').forEach(o => {
  o.addEventListener('click', ev => { if(ev.target===o && o.id!=='mProc') CM2(o.id); });
});

/* ─ COUNTDOWN ─ */
window.startCD = (onDone) => {
  let t = 30;
  document.getElementById('cdN').textContent = t;
  OM('mProc');
  const iv = setInterval(() => {
    t--;
    document.getElementById('cdN').textContent = t;
    if(t <= 0){ clearInterval(iv); CM2('mProc'); onDone(); }
  }, 1000);
};

/* ─ COPY TEXT ─ */
window.cpTxt = (text, btn) => {
  const fb = () => { const ta=document.createElement('textarea'); ta.value=text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta); };
  (navigator.clipboard ? navigator.clipboard.writeText(text).catch(fb) : Promise.resolve(fb()))
    .then(() => { const o=btn.textContent; btn.textContent='Copied!'; setTimeout(()=>btn.textContent=o, 1500); });
};

/* ─ TOAST ─ */
window.showToast = (msg, dur=2200) => {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('on');
  setTimeout(() => t.classList.remove('on'), dur);
};