
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, collection, getDocs, addDoc, query, orderBy, doc, getDoc }
  from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

/* ════ PASTE YOUR FIREBASE CONFIG HERE ════ */
const firebaseConfig = {
  apiKey: "AIzaSyCwhf1lOtZXj13wyrNI0mfUSeQj8Cs3iJM",
  authDomain: "gkchat-959fb.firebaseapp.com",
  databaseURL: "https://gkchat-959fb-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "gkchat-959fb",
  storageBucket: "gkchat-959fb.firebasestorage.app",
  messagingSenderId: "654177877506",
  appId: "1:654177877506:web:9b1f302686c9f408e3311b"
};
/* ========================================= */

const fbApp = initializeApp(firebaseConfig);
const db    = getFirestore(fbApp);
window._T=[]; window._A=[]; window._P=[]; window._W=[]; window._socialLinks={};

/* Capture the URL params the page was opened with, right away —
   before any other script can touch history.replaceState/pushState */
window._deepLinkParams = new URLSearchParams(location.search);

/* ─ Load all data ─ */
async function loadAll(){
  try{
    const [ts,as,ps,ws,setSnap] = await Promise.all([
      getDocs(query(collection(db,'tools'),    orderBy('createdAt','desc'))),
      getDocs(query(collection(db,'apps'),     orderBy('createdAt','desc'))),
      getDocs(query(collection(db,'projects'), orderBy('createdAt','desc'))),
      getDocs(query(collection(db,'websites'), orderBy('createdAt','desc'))),
      getDoc(doc(db,'settings','unlock'))
    ]);
    window._T = ts.docs.map(d=>({id:d.id,...d.data()}));
    window._A = as.docs.map(d=>({id:d.id,...d.data()}));
    window._P = ps.docs.map(d=>({id:d.id,...d.data()}));
    window._W = ws.docs.map(d=>({id:d.id,...d.data()}));
    window._socialLinks = setSnap.exists() ? setSnap.data() : {};

    /* Home trending: clicking goes to LIST page */
    rg('hT', window._T.slice(0,6), 'tool', 'list');
    rg('hA', window._A.slice(0,4), 'app',  'list');
    rg('hP', window._P.slice(0,4), 'proj', 'list');
    rg('hW', window._W.slice(0,4), 'website', 'list');

    /* List pages: clicking goes to DETAIL page */
    rg('gT', window._T, 'tool', 'detail');
    rg('gA', window._A, 'app',  'detail');
    rg('gP', window._P, 'proj', 'detail');
    rg('gW', window._W, 'website', 'detail');

    /* Check URL params for direct deep link */
    routeURL();
  } catch(err){
    document.querySelectorAll('.lding').forEach(el=>el.textContent='Firebase not configured. See README.');
    console.error(err);
  }
}
loadAll();

/* ─ Render grid ─
   mode: 'list' = card click goes to section list page
         'detail' = card click goes to item detail page         */
function rg(cid, items, type, mode){
  const g = document.getElementById(cid);
  if(!g) return;
  if(!items||!items.length){ g.innerHTML='<p class="empty">No items added yet. Check back soon!</p>'; return; }
  g.innerHTML = items.map(item => mkCard(item, type, mode)).join('');
}

function mkCard(item, type, mode){
  const img  = esc(item.img || 'https://placehold.co/300x200?text=No+Image');
  const name = esc(item.name || 'Untitled');
  const id   = item.id;

  /* What happens when card (or main btn) is clicked */
  let mainClick='', btnLabel='', btnIcon='';
  if(mode === 'list'){
    /* Home → go to list page */
    mainClick = type==='tool'?`go('tools')`: type==='app'?`go('apps')`: type==='website'?`go('websites')`:`go('projects')`;
    btnLabel  = 'View All';
    btnIcon   = type==='tool'?'i-tool': type==='app'?'i-app': type==='website'?'i-web':'i-proj';
  } else {
    /* List page → go to detail page */
    mainClick = `openDetail('${type}','${id}')`;
    btnLabel  = type==='tool'?'Details': type==='app'?'Install': type==='website'?'Visit':'Download';
    btnIcon   = type==='tool'?'i-tool': type==='app'?'i-inst': type==='website'?'i-ext':'i-dl';
  }

  return `<div class="card" onclick="${mainClick}">
    <img class="card-img" src="${img}" alt="${name}" loading="lazy" onerror="this.src='https://placehold.co/300x200?text=No+Image'">
    <div class="card-body">
      <div class="card-name">${name}</div>
      <div class="card-row">
        <button class="cbtn a" onclick="event.stopPropagation();${mainClick}">
          <svg viewBox="0 0 24 24"><use href="#${btnIcon}"/></svg>${btnLabel}
        </button>
        <button class="cbtn ic" onclick="event.stopPropagation();shareItem('${type}','${id}')" title="Share">
          <svg viewBox="0 0 24 24"><use href="#i-share"/></svg>
        </button>
      </div>
    </div>
  </div>`;
}

/* ─ Open detail page ─ */
window.openDetail = (type, id) => {
  if(type==='tool') openToolDetail(id);
  else if(type==='app')  openAppDetail(id);
  else if(type==='website') openWebsiteDetail(id);
  else openProjDetail(id);
};

/* ── TOOL DETAIL PAGE ── */
window.openToolDetail = (id) => {
  const t = window._T.find(x=>x.id===id);
  if(!t) return;
  document.getElementById('tdi').src = t.img||'';
  document.getElementById('tdn').textContent = t.name||'';
  document.getElementById('tdd').textContent = t.description||'';
  /* actions */
  document.getElementById('tda').innerHTML =
    (t.githubLink ? `<a href="${t.githubLink}" class="btn o" target="_blank"><svg viewBox="0 0 24 24"><use href="#i-code"/></svg>GitHub</a>` : '') +
    `<button class="btn sc" onclick="shareItem('tool','${id}')"><svg viewBox="0 0 24 24"><use href="#i-share"/></svg>Share</button>`;
  /* commands */
  const cmds = t.commands||[];
  document.getElementById('tdc').innerHTML = cmds.length
    ? `<div class="cmds"><h4><svg viewBox="0 0 24 24"><use href="#i-cmd"/></svg>Commands</h4>${cmds.map(c=>`<div class="cmd-row"><code>${c}</code><button class="cpbtn" onclick="cpTxt('${esc(c)}',this)">Copy</button></div>`).join('')}</div>` : '';
  /* video */
  document.getElementById('tdv').innerHTML = t.videoUrl
    ? `<div class="vids"><h4><svg viewBox="0 0 24 24"><use href="#i-vid"/></svg>Video Tutorial</h4><div class="vwrap"><iframe src="${ytEmbed(t.videoUrl)}" allowfullscreen></iframe></div></div>` : '';
  go('tool-detail', 'tool', id);
};

/* ── APP DETAIL PAGE ── */
window.openAppDetail = (id) => {
  const a = window._A.find(x=>x.id===id);
  if(!a) return;
  document.getElementById('adi').src = a.img||'';
  document.getElementById('adn').textContent = a.name||'';
  document.getElementById('add').textContent = a.description||'';
  document.getElementById('ada').innerHTML =
    `<button class="btn p" onclick="openAppModal('${id}')"><svg viewBox="0 0 24 24"><use href="#i-inst"/></svg>Install App</button>
     <button class="btn sc" onclick="shareItem('app','${id}')"><svg viewBox="0 0 24 24"><use href="#i-share"/></svg>Share</button>`;
  document.getElementById('adv').innerHTML = a.videoUrl
    ? `<div class="vids"><h4><svg viewBox="0 0 24 24"><use href="#i-vid"/></svg>Video</h4><div class="vwrap"><iframe src="${ytEmbed(a.videoUrl)}" allowfullscreen></iframe></div></div>` : '';
  go('app-detail', 'app', id);
};

/* App install modal (from detail page) */
window.openAppModal = (id) => {
  const a = window._A.find(x=>x.id===id);
  if(!a) return;
  window._instLink = a.downloadLink||'';
  window._instCode = a.code||'';
  document.getElementById('mA-img').src = a.img||'';
  document.getElementById('mA-name').textContent = a.name||'';
  OM('mApp');
};

window.startInstall = () => {
  CM2('mApp');
  proceedWithCode(window._instCode, () => {
    startCD(() => {
      setDoneModal('Install Now','Your app is ready to install.','i-inst', window._instLink);
      OM('mDone');
    });
  });
};

/* ── PROJECT DETAIL PAGE ── */
window.openProjDetail = (id) => {
  const p = window._P.find(x=>x.id===id);
  if(!p) return;
  document.getElementById('pdi').src = p.img||'';
  document.getElementById('pdn').textContent = p.name||'';
  document.getElementById('pdd').textContent = p.description||'';
  let acts = '';
  if(p.liveLink)   acts += `<a href="${p.liveLink}" class="btn o" target="_blank"><svg viewBox="0 0 24 24"><use href="#i-ext"/></svg>Live Preview</a>`;
  if(p.sourceLink) acts += `<a href="${p.sourceLink}" class="btn sc" target="_blank"><svg viewBox="0 0 24 24"><use href="#i-code"/></svg>Source Code</a>`;
  acts += `<button class="btn p" onclick="openProjModal('${id}')"><svg viewBox="0 0 24 24"><use href="#i-dl"/></svg>Download ZIP</button>`;
  acts += `<button class="btn sc" onclick="shareItem('proj','${id}')"><svg viewBox="0 0 24 24"><use href="#i-share"/></svg>Share</button>`;
  document.getElementById('pda').innerHTML = acts;
  go('project-detail', 'proj', id);
};

/* Project modal (from detail page) */
window.openProjModal = (id) => {
  const p = window._P.find(x=>x.id===id);
  if(!p) return;
  window._projDl = p.downloadLink||'';
  window._projCode = p.code||'';
  document.getElementById('mP-img').src = p.img||'';
  document.getElementById('mP-name').textContent = p.name||'';
  let acts = '';
  if(p.liveLink)   acts += `<a href="${p.liveLink}" class="btn o sm" target="_blank"><svg viewBox="0 0 24 24"><use href="#i-ext"/></svg>Live Preview</a>`;
  if(p.sourceLink) acts += `<a href="${p.sourceLink}" class="btn sc sm" target="_blank"><svg viewBox="0 0 24 24"><use href="#i-code"/></svg>Source Code</a>`;
  acts += `<button class="btn p sm" onclick="startProjDl()"><svg viewBox="0 0 24 24"><use href="#i-dl"/></svg>Download ZIP</button>`;
  document.getElementById('mP-acts').innerHTML = acts;
  OM('mProj');
};

window.startProjDl = () => {
  CM2('mProj');
  proceedWithCode(window._projCode, () => {
    startCD(() => {
      setDoneModal('Download ZIP','Your file is ready to download.','i-dl', window._projDl);
      OM('mDone');
    });
  });
};

/* ── WEBSITE DETAIL PAGE ── */
window.openWebsiteDetail = (id) => {
  const w = window._W.find(x=>x.id===id);
  if(!w) return;
  document.getElementById('wdi').src = w.img||'';
  document.getElementById('wdn').textContent = w.name||'';
  document.getElementById('wdd').textContent = w.description||'';
  let acts = '';
  if(w.websiteLink) acts += `<a href="${w.websiteLink}" class="btn p" target="_blank" rel="noopener"><svg viewBox="0 0 24 24"><use href="#i-ext"/></svg>Visit Website</a>`;
  acts += `<button class="btn sc" onclick="shareItem('website','${id}')"><svg viewBox="0 0 24 24"><use href="#i-share"/></svg>Share</button>`;
  document.getElementById('wda').innerHTML = acts;
  /* video */
  document.getElementById('wdv').innerHTML = w.videoUrl
    ? `<div class="vids"><h4><svg viewBox="0 0 24 24"><use href="#i-vid"/></svg>Video</h4><div class="vwrap"><iframe src="${ytEmbed(w.videoUrl)}" allowfullscreen></iframe></div></div>` : '';
  go('website-detail', 'website', id);
};

/* ── CONFIRMATION CODE GATE ──
   Every app/project gets a random code (set in admin). Before the
   processing countdown starts, the visitor must type that exact code. */
let _codeCallback = null;
function proceedWithCode(code, onSuccess){
  if(!code){ onSuccess(); return; } // no code set for this item — skip the gate
  window._expectedCode = code.toUpperCase();
  _codeCallback = onSuccess;
  document.getElementById('codeInput').value = '';
  document.getElementById('codeErr').textContent = '';
  OM('mCode');
}

window.verifyCode = () => {
  const val = document.getElementById('codeInput').value.trim().toUpperCase();
  if(val && val === window._expectedCode){
    document.getElementById('codeErr').textContent = '';
    CM2('mCode');
    const cb = _codeCallback; _codeCallback = null;
    if(cb) cb();
  } else {
    document.getElementById('codeErr').textContent = 'Incorrect code. Please check and try again.';
  }
};

function setDoneModal(label, sub, icon, href){
  document.getElementById('mDone-title').textContent = 'Ready!';
  document.getElementById('mDone-sub').textContent = sub;
  const btn = document.getElementById('mDone-btn');
  btn.href = href;
  btn.innerHTML = `<svg viewBox="0 0 24 24"><use href="#${icon}"/></svg>${label}`;
  renderUnlock();
}

/* ── Convert a normal YouTube link (watch / youtu.be / shorts) into an embed URL ── */
function ytEmbed(url){
  if(!url) return '';
  const m = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/|live\/)|youtu\.be\/)([a-zA-Z0-9_-]{6,15})/);
  return m ? `https://www.youtube.com/embed/${m[1]}` : url;
}

/* ── SUBSCRIBE TO UNLOCK ──
   Visitor must open each configured social link before the install/download
   button is revealed. Unlocked state is remembered in localStorage so it
   persists across visits — once a link is checked off, it stays checked. */
const SOCIAL_META = {
  youtube:   { label: 'Subscribe on YouTube',   icon: 'i-yt' },
  telegram:  { label: 'Join our Telegram',      icon: 'i-tg' },
  instagram: { label: 'Follow on Instagram',    icon: 'i-ig' },
  whatsapp:  { label: 'Join on WhatsApp',       icon: 'i-wa' }
};

function unlockKeys(){
  return Object.keys(SOCIAL_META).filter(k => window._socialLinks && window._socialLinks[k]);
}

function renderUnlock(){
  const wrap = document.getElementById('mDoneUnlock');
  const keys = unlockKeys();
  if(!keys.length){ wrap.innerHTML=''; checkUnlockComplete(); return; }
  wrap.innerHTML = `<p class="ulk-note">One quick step before you continue:</p><div class="ulk-grid">` +
    keys.map(k => {
      const done = localStorage.getItem('ulk_'+k) === '1';
      return `<button type="button" class="ulk-btn${done?' done':''}" id="ulk-${k}" onclick="unlockClick('${k}')">
        <svg viewBox="0 0 24 24"><use href="#${SOCIAL_META[k].icon}"/></svg>
        <span>${SOCIAL_META[k].label}</span>
        <svg class="ulk-tick" viewBox="0 0 24 24"><use href="#i-check"/></svg>
      </button>`;
    }).join('') + `</div>`;
  checkUnlockComplete();
}

window.unlockClick = (key) => {
  const url = window._socialLinks && window._socialLinks[key];
  if(url) window.open(url, '_blank', 'noopener');
  localStorage.setItem('ulk_'+key, '1');
  const btn = document.getElementById('ulk-'+key);
  if(btn) btn.classList.add('done');
  checkUnlockComplete();
};

function checkUnlockComplete(){
  const keys = unlockKeys();
  const allDone = keys.every(k => localStorage.getItem('ulk_'+k) === '1');
  const dlBtn = document.getElementById('mDone-btn');
  if(dlBtn) dlBtn.style.display = allDone ? 'inline-flex' : 'none';
}

/* ── SEARCH ── */
window.doSearch = (q) => {
  q = (q||'').trim().toLowerCase();
  if(!q) return;
  document.getElementById('si').value = q;
  document.getElementById('stitle').textContent = `Results for "${q}"`;
  const ft = window._T.filter(t=>(t.name||'').toLowerCase().includes(q));
  const fa = window._A.filter(a=>(a.name||'').toLowerCase().includes(q));
  const fp = window._P.filter(p=>(p.name||'').toLowerCase().includes(q));
  const fw = window._W.filter(w=>(w.name||'').toLowerCase().includes(q));
  let html = '';
  if(ft.length) html += `<h2 class="stitle">Tools</h2><div class="grid">${ft.map(t=>mkCard(t,'tool','detail')).join('')}</div>`;
  if(fa.length) html += `<h2 class="stitle">Apps</h2><div class="grid two">${fa.map(a=>mkCard(a,'app','detail')).join('')}</div>`;
  if(fp.length) html += `<h2 class="stitle">Projects</h2><div class="grid two">${fp.map(p=>mkCard(p,'proj','detail')).join('')}</div>`;
  if(fw.length) html += `<h2 class="stitle">Websites</h2><div class="grid two">${fw.map(w=>mkCard(w,'website','detail')).join('')}</div>`;
  if(!html) html = `<p class="empty">No results for "${q}".</p>`;
  document.getElementById('sres').innerHTML = html;
  go('search');
};

/* ── SHARE ── */
window.shareItem = (type, id) => {
  const key = type==='proj' ? 'project' : type;
  const url = `${location.origin}${location.pathname}?${key}=${id}`;
  if(navigator.share){ navigator.share({title:'MyHub', url}).catch(()=>{}); return; }
  navigator.clipboard.writeText(url)
    .then(()=>showToast('Link copied!'))
    .catch(()=>{ prompt('Copy this link:', url); });
};

/* ── URL ROUTING (share links) ── */
function routeURL(){
  const p = window._deepLinkParams || new URLSearchParams(location.search);
  if(p.get('tool'))    { openToolDetail(p.get('tool'));       return; }
  if(p.get('app'))     { openAppDetail(p.get('app'));         return; }
  if(p.get('project')) { openProjDetail(p.get('project'));    return; }
  if(p.get('website')) { openWebsiteDetail(p.get('website')); return; }
}

/* ── SUBSCRIBE ── */
window.handleSubscribe = async (e) => {
  e.preventDefault();
  const name  = document.getElementById('subName').value.trim();
  const email = document.getElementById('subEmail').value.trim();
  if(!name||!email) return;
  try {
    await addDoc(collection(db,'subscribers'),{name,email,date:new Date().toISOString()});
    document.getElementById('subscribeForm').style.display='none';
    document.getElementById('thanksMsg').style.display='block';
  } catch(err){ alert('Could not subscribe. Please try again.'); }
};

/* ── CONTACT ── */
window.sendContact = async () => {
  const n=document.getElementById('cN').value.trim(), e=document.getElementById('cE').value.trim(), m=document.getElementById('cM').value.trim();
  if(!n||!e||!m){ showToast('Please fill all fields.'); return; }
  try{
    await addDoc(collection(db,'messages'),{name:n,email:e,message:m,date:new Date().toISOString()});
    document.getElementById('cOk').style.display='block';
    ['cN','cE','cM'].forEach(id=>document.getElementById(id).value='');
  } catch(err){ showToast('Could not send. Try again.'); }
};

function esc(s){ return String(s).replace(/'/g,"&#39;").replace(/"/g,"&quot;"); }
